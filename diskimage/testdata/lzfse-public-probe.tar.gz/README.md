# Bounded public UDIF LZFSE probe

This bundle contains code, metadata and digests only. No firmware bytes or native filesystem operations are included.

The original probe reproduced `diskimage.New: UDIF chunk codec 0x80000007: unsupported feature`. With the same cached ranges, the patched reader opened UDIF/GPT and decoded the first 4096 logical bytes. Across both runs, only 648,112 response-body bytes were fetched in 5 exact 206 responses; the largest was 458,752 bytes. The patched run made no network requests.

This proves metadata/prefix-only opening. It does not qualify the complete IPSW, complete DMG, decoded disk or APFS filesystem. ZIP CRC is unverified directory metadata, not a completed member integrity verdict. The decoded-prefix SHA256 covers 4096 logical bytes only.

`public-udif-lzfse-probe.json` records the original baseline and patched module heads, the patched working-tree production diff digest, exact original source/receipt/harness hashes, all enforced limits and every range receipt. `production-source.diff` is code only and reproduces the three production source changes used at the original probe. The original patched module head predates its uncommitted changes; the diff and per-file hashes identify those exact bytes.

The complete temporary harness and rejection-path tests are included unchanged as `probe.go` and `probe_http_test.go`. Run the harness from each appropriate Go module directory so imports resolve to that implementation. Create a new private empty cache directory, run baseline first, then patched using the same cache/ledger. Commands are recorded in the JSON. The original private evidence/cache is retained at `/private/tmp/apfs-lzfse-public-probe.8wcuHc`; original files and hashes were not changed when preparing this bundle.

package main

import (
	"bytes"
	"context"
	"io"
	"net/http"
	"strings"
	"testing"
)

type transport func(*http.Request) (*http.Response, error)

func (f transport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

type countingBody struct {
	reader io.Reader
	reads  int
}

func (b *countingBody) Read(p []byte) (int, error) { b.reads++; return b.reader.Read(p) }
func (b *countingBody) Close() error               { return nil }
func TestRejectedResponsesNeverReadTheBody(t *testing.T) {
	for _, tc := range []struct {
		name     string
		status   int
		length   int64
		cr, etag string
	}{
		{"full response", 200, 2, "bytes 0-1/4", "\"stable\""},
		{"changed range", 206, 2, "bytes 1-2/4", "\"stable\""},
		{"changed size", 206, 2, "bytes 0-1/5", "\"stable\""},
		{"changed etag", 206, 2, "bytes 0-1/4", "\"changed\""},
		{"unknown length", 206, -1, "bytes 0-1/4", "\"stable\""},
	} {
		t.Run(tc.name, func(t *testing.T) {
			b := &countingBody{reader: strings.NewReader("xx")}
			s := &rangeSource{ctx: context.Background(), dir: t.TempDir(), state: state{URL: publicURL, Size: 4, ETag: "\"stable\""}, client: &http.Client{Transport: transport(func(r *http.Request) (*http.Response, error) {
				return &http.Response{StatusCode: tc.status, ContentLength: tc.length, Header: http.Header{"Content-Range": {tc.cr}, "Etag": {tc.etag}}, Body: b}, nil
			})}}
			if _, e := s.fetch(0, 2); e == nil {
				t.Fatal("unsafe response accepted")
			}
			if b.reads != 0 {
				t.Fatal("rejected response body read")
			}
		})
	}
}
func TestValidResponseBindsCacheAndEnforcesAbsoluteBudgets(t *testing.T) {
	called := 0
	s := &rangeSource{ctx: context.Background(), dir: t.TempDir(), client: &http.Client{Transport: transport(func(r *http.Request) (*http.Response, error) {
		called++
		if r.Header.Get("Range") != "bytes=0-1" {
			t.Fatal("wrong range")
		}
		return &http.Response{StatusCode: 206, ContentLength: 2, Header: http.Header{"Content-Range": {"bytes 0-1/4"}, "Etag": {"\"stable\""}}, Body: io.NopCloser(bytes.NewReader([]byte("ab")))}, nil
	})}}
	b, e := s.fetch(0, 2)
	if e != nil || string(b) != "ab" || s.state.ReadBodyBytes != 2 || s.state.ReservedRangeBytes != 2 || len(s.state.Chunks) != 1 {
		t.Fatalf("valid range/cache failed: %q %v %+v", b, e, s.state)
	}
	for _, tc := range []struct {
		requests    int
		reserved, n int64
	}{{128, 2, 1}, {1, budget - 1, 2}, {1, 2, requestLimit + 1}} {
		s.state.Requests = tc.requests
		s.state.ReservedRangeBytes = tc.reserved
		if _, e := s.fetch(0, tc.n); e == nil {
			t.Fatal("absolute budget accepted")
		}
	}
	if called != 1 {
		t.Fatal("budget refusal performed an HTTP request")
	}
}

package main

import (
	"archive/zip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/deploymenttheory/go-apfs-v3/diskimage"
)

const publicURL = "https://updates.cdn-apple.com/2020SummerFCS/fullrestores/001-46828/6A00C15C-8AEB-490E-A468-04E28C68E7C9/iPhone11,8,iPhone12,1_14.0_18A373_Restore.ipsw"
const memberName = "038-03664-370.dmg"
const budget int64 = 32 << 20
const requestLimit int64 = 16 << 20
const requestCountLimit = 128
const cacheAlignment int64 = 64 << 10

type chunk struct {
	Offset, Length int64
	SHA256, File   string
}
type state struct {
	URL                               string
	Size                              int64
	ETag                              string
	Requests                          int
	ReservedRangeBytes, ReadBodyBytes int64
	Chunks                            []chunk
}
type receipt struct {
	Label              string
	Request            int
	At                 time.Time
	Offset, Length     int64
	Status             int
	ContentRange, ETag string
	ReadBodyBytes      int
	SHA256             string
	Error              string
}
type rangeSource struct {
	mu                    sync.Mutex
	ctx                   context.Context
	client                *http.Client
	dir, label            string
	state                 state
	cacheHits, cacheBytes int64
}

func sum(b []byte) string { x := sha256.Sum256(b); return hex.EncodeToString(x[:]) }
func writeJSON(path string, x any) error {
	b, e := json.MarshalIndent(x, "", "  ")
	if e != nil {
		return e
	}
	return os.WriteFile(path, append(b, '\n'), 0600)
}
func (s *rangeSource) save() error { return writeJSON(filepath.Join(s.dir, "state.json"), s.state) }
func (s *rangeSource) Size() int64 { return s.state.Size }
func (s *rangeSource) fetch(off, n int64) (data []byte, resultErr error) {
	if n <= 0 || n > requestLimit || off < 0 || s.state.Requests >= requestCountLimit || n > budget-s.state.ReservedRangeBytes {
		return nil, fmt.Errorf("probe request or global range budget exceeded: off=%d length=%d requests=%d reserved=%d", off, n, s.state.Requests, s.state.ReservedRangeBytes)
	}
	if s.state.Size > 0 && (off >= s.state.Size || n > s.state.Size-off) {
		return nil, errors.New("request beyond archive")
	}
	s.state.Requests++
	s.state.ReservedRangeBytes += n
	if e := s.save(); e != nil {
		return nil, e
	}
	rec := receipt{Label: s.label, Request: s.state.Requests, At: time.Now().UTC(), Offset: off, Length: n}
	defer func() {
		if resultErr != nil {
			rec.Error = resultErr.Error()
		}
		f, e := os.OpenFile(filepath.Join(s.dir, "ranges.jsonl"), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
		if e == nil {
			e = json.NewEncoder(f).Encode(rec)
			e = errors.Join(e, f.Close())
		}
		resultErr = errors.Join(resultErr, e, s.save())
	}()
	req, e := http.NewRequestWithContext(s.ctx, http.MethodGet, publicURL, nil)
	if e != nil {
		return nil, e
	}
	req.Header.Set("Range", fmt.Sprintf("bytes=%d-%d", off, off+n-1))
	req.Header.Set("Accept-Encoding", "identity")
	if s.state.ETag != "" {
		req.Header.Set("If-Match", s.state.ETag)
	}
	resp, e := s.client.Do(req)
	if e != nil {
		return nil, e
	}
	defer resp.Body.Close()
	rec.Status = resp.StatusCode
	rec.ContentRange = resp.Header.Get("Content-Range")
	rec.ETag = resp.Header.Get("ETag")
	// Do not read any body from a full response, redirect, or metadata mismatch.
	if resp.StatusCode != http.StatusPartialContent {
		return nil, fmt.Errorf("refused HTTP %d without reading body", resp.StatusCode)
	}
	var a, b, total int64
	if _, e = fmt.Sscanf(rec.ContentRange, "bytes %d-%d/%d", &a, &b, &total); e != nil || rec.ContentRange != fmt.Sprintf("bytes %d-%d/%d", off, off+n-1, total) || a != off || b != off+n-1 || total <= b {
		return nil, fmt.Errorf("invalid exact Content-Range %q", rec.ContentRange)
	}
	if resp.ContentLength != n || resp.Header.Get("Content-Encoding") != "" && resp.Header.Get("Content-Encoding") != "identity" {
		return nil, fmt.Errorf("invalid response length/encoding: length=%d encoding=%q", resp.ContentLength, resp.Header.Get("Content-Encoding"))
	}
	if rec.ETag == "" || strings.HasPrefix(rec.ETag, "W/") {
		return nil, fmt.Errorf("missing or weak archive ETag %q", rec.ETag)
	}
	if s.state.Size != 0 && (s.state.Size != total || s.state.ETag != rec.ETag) {
		return nil, errors.New("archive size or ETag changed")
	}
	if s.state.Size == 0 {
		s.state.Size = total
		s.state.ETag = rec.ETag
	}
	data = make([]byte, int(n))
	read, e := io.ReadFull(resp.Body, data)
	rec.ReadBodyBytes = read
	s.state.ReadBodyBytes += int64(read)
	if e != nil {
		return nil, e
	}
	var extra [1]byte
	read, e = resp.Body.Read(extra[:])
	s.state.ReadBodyBytes += int64(read)
	rec.ReadBodyBytes += read
	if read != 0 || e != io.EOF {
		return nil, fmt.Errorf("response length boundary: extra=%d error=%v", read, e)
	}
	rec.SHA256 = sum(data)
	name := fmt.Sprintf("range-%012d-%09d.bin", off, n)
	if e = os.WriteFile(filepath.Join(s.dir, name), data, 0600); e != nil {
		return nil, e
	}
	s.state.Chunks = append(s.state.Chunks, chunk{Offset: off, Length: n, SHA256: rec.SHA256, File: name})
	return data, nil
}
func (s *rangeSource) ReadAt(p []byte, off int64) (int, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if off < 0 {
		return 0, errors.New("negative range offset")
	}
	if len(p) == 0 {
		return 0, nil
	}
	if off >= s.state.Size {
		return 0, io.EOF
	}
	wanted := len(p)
	if int64(wanted) > s.state.Size-off {
		wanted = int(s.state.Size - off)
	}
	done := 0
	for done < wanted {
		if e := s.ctx.Err(); e != nil {
			return done, e
		}
		at := off + int64(done)
		var data []byte
		var start int64
		for _, c := range s.state.Chunks {
			if at >= c.Offset && at < c.Offset+c.Length {
				b, e := os.ReadFile(filepath.Join(s.dir, c.File))
				if e != nil {
					return done, e
				}
				if int64(len(b)) != c.Length || sum(b) != c.SHA256 {
					return done, errors.New("cached range digest/length changed")
				}
				data, start = b, c.Offset
				s.cacheHits++
				break
			}
		}
		if data == nil {
			start = at / cacheAlignment * cacheAlignment
			end := min(s.state.Size, start+requestLimit, ((off+int64(wanted)+cacheAlignment-1)/cacheAlignment)*cacheAlignment)
			var e error
			data, e = s.fetch(start, end-start)
			if e != nil {
				return done, e
			}
		} else {
			s.cacheBytes += min(int64(wanted-done), int64(len(data))-(at-start))
		}
		got := copy(p[done:wanted], data[at-start:])
		if got == 0 {
			return done, errors.New("range cache made no progress")
		}
		done += got
	}
	if done < len(p) {
		return done, io.EOF
	}
	return done, nil
}

type memberSource struct {
	*io.SectionReader
	length int64
}

func (s memberSource) Size() int64 { return s.length }
func probe(s *rangeSource, result map[string]any) error {
	if s.state.Size == 0 {
		if _, e := s.fetch(0, 1); e != nil {
			return e
		}
	}
	result["archiveSize"] = s.state.Size
	result["archiveETag"] = s.state.ETag
	zr, e := zip.NewReader(s, s.Size())
	if e != nil {
		return fmt.Errorf("ZIP metadata: %w", e)
	}
	var member *zip.File
	for _, f := range zr.File {
		if f.Name == memberName {
			if member != nil {
				return errors.New("ambiguous stored member")
			}
			member = f
		}
	}
	if member == nil {
		return errors.New("stored member missing")
	}
	if member.Method != zip.Store || member.CompressedSize64 != member.UncompressedSize64 || member.UncompressedSize64 != 5223921616 {
		return fmt.Errorf("member method/size mismatch: method=%d compressed=%d uncompressed=%d", member.Method, member.CompressedSize64, member.UncompressedSize64)
	}
	offset, e := member.DataOffset()
	if e != nil {
		return e
	}
	size := int64(member.UncompressedSize64)
	if offset < 0 || offset > s.Size() || size > s.Size()-offset {
		return errors.New("stored member range outside archive")
	}
	result["member"] = map[string]any{"name": member.Name, "method": member.Method, "offset": offset, "size": size, "zipCRC32": fmt.Sprintf("%08x", member.CRC32)}
	section := memberSource{io.NewSectionReader(s, offset, size), size}
	img, e := diskimage.New(section)
	if e != nil {
		return fmt.Errorf("diskimage.New: %w", e)
	}
	defer img.Close()
	result["image"] = img
	result["logicalSize"] = img.Size()
	b := make([]byte, 4096)
	n, e := img.ReadAt(b, 0)
	if e != nil {
		return fmt.Errorf("decoded prefix: %w", e)
	}
	result["decodedPrefix"] = map[string]any{"offset": 0, "bytes": n, "sha256": sum(b)}
	return nil
}
func main() {
	dir := flag.String("cache", "", "private range-cache directory")
	label := flag.String("label", "probe", "result label")
	flag.Parse()
	if *dir == "" || (*label != "baseline" && *label != "patched") {
		panic("use -cache and -label baseline|patched")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Minute)
	defer cancel()
	s := &rangeSource{ctx: ctx, dir: *dir, label: *label, client: &http.Client{Timeout: 45 * time.Second, Transport: &http.Transport{DisableCompression: true}, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}}
	b, e := os.ReadFile(filepath.Join(*dir, "state.json"))
	if e == nil {
		if e = json.Unmarshal(b, &s.state); e != nil {
			panic(e)
		}
	} else if !os.IsNotExist(e) {
		panic(e)
	}
	if s.state.URL != "" && s.state.URL != publicURL {
		panic("cache URL changed")
	}
	s.state.URL = publicURL
	beforeRequests, beforeBytes := s.state.Requests, s.state.ReadBodyBytes
	result := map[string]any{"label": *label, "url": publicURL, "startedAt": time.Now().UTC(), "limits": map[string]any{"totalBodyBytes": budget, "perRequestBytes": requestLimit, "requests": requestCountLimit, "timeout": "4m"}, "scope": "Bounded metadata and decoded-prefix probe only; no full archive/member download, full hash, or filesystem qualification."}
	e = probe(s, result)
	if e != nil {
		result["error"] = e.Error()
	}
	result["completedAt"] = time.Now().UTC()
	result["totalRequests"] = s.state.Requests
	result["totalBodyBytes"] = s.state.ReadBodyBytes
	result["totalReservedRangeBytes"] = s.state.ReservedRangeBytes
	result["runRequests"] = s.state.Requests - beforeRequests
	result["runBodyBytes"] = s.state.ReadBodyBytes - beforeBytes
	result["cacheHits"] = s.cacheHits
	result["cacheBytes"] = s.cacheBytes
	if w := writeJSON(filepath.Join(*dir, *label+".json"), result); w != nil {
		panic(w)
	}
	out, _ := json.MarshalIndent(result, "", "  ")
	fmt.Println(string(out))
	if e != nil {
		os.Exit(1)
	}
}

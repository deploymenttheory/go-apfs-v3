# Read-only UDIF LZFSE review

Reviewed the three production files and `diskimage/udif_lzfse_test.go` against issue 146, AGENTS.md, CONTRIBUTING.md and the existing UDIF/cache/source contracts. No repository files were edited. The production file hashes match the original successful bounded public probe; `production-source.diff` records the exact production delta.

## Standards

No blocking findings. The change stays in the disk-image/codec layers, with no CLI or native-capture dependency. File/test names describe the codec capability. Existing captured observations remain untouched, and the independent C-generated compressed vector records its pinned source revision, generation formula and hashes. The public probe bundle contains code, metadata and digests only.

## Spec and bounds

No blocking findings. Codec 0x80000007 is admitted through the existing UDIF reader. The existing source ranges, 16 MiB plist bound, 64 MiB stored/decoded compressed-chunk bounds and 64 MiB decoded-cache budget remain intact. Input and destination buffers are allocated only after admission; destination size is fixed. DecodeExact requires the stream end marker to consume the complete stored range, while Decode retains its prior prefix semantics. Malformed or length-mismatched output is cleared, not exposed or cached. The zlib/bzip2 extraction preserves their prior bounded decoding path.

Synthetic tests cover successful stored-block and independently C-encoded bvx2 streams, random-range readback, truncated headers/payloads/end markers, unknown blocks, trailing bytes/second streams, short/overlong decoded output, unchanged caller output/cache on failure, decoded chunk limits and borrowed section EOF behavior. The bounded public-image probe independently reproduces the baseline refusal and opens UDIF/GPT with the patched reader, but proves metadata/prefix opening only.

One optional test-strengthening suggestion: extend TestUDIFLZFSEKeepsChunkAndSourceBounds with a sparse/counting Source that advertises storedSize > 64 MiB while keeping the underlying test bytes small; assert rejection before any stored payload read/allocation. Current code correctly applies this shared bound, but the new LZFSE limit test explicitly exercises decoded size only. This is not a production defect or a reason to weaken/change the existing bound.

## Validation

`GOCACHE=/private/tmp/go-apfs-v3-build go test -race -count=1 ./diskimage ./internal/codec/lzfse` passed: diskimage 32.664s; the codec package has no standalone test files. No native filesystem commands or additional downloads were run for this review.
